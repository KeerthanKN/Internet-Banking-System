/*
SQLyog Ultimate v8.55 
MySQL - 5.1.54-community : Database - bank
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`bank` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `bank`;

/*Table structure for table `accountconfig` */

DROP TABLE IF EXISTS `accountconfig`;

CREATE TABLE `accountconfig` (
  `param` varchar(20) DEFAULT NULL,
  `value` int(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `accountconfig` */

insert  into `accountconfig`(`param`,`value`) values ('numseq',4);

/*Table structure for table `accounts` */

DROP TABLE IF EXISTS `accounts`;

CREATE TABLE `accounts` (
  `username` varchar(30) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL,
  `accountnum` varchar(20) DEFAULT NULL,
  `amount` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `accounts` */

insert  into `accounts`(`username`,`password`,`accountnum`,`amount`) values ('baavi','baavi','123456','47607.0'),('gowri','gowri','12343455667','2000.0'),('raghu','12345','EPCETISE5-1','2500.0'),('likitha','1234567','EPCETISE5-2','9000.0'),('chethana','12345678','EPCETISE5-3','5000.0');

/*Table structure for table `admin` */

DROP TABLE IF EXISTS `admin`;

CREATE TABLE `admin` (
  `username` varchar(30) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `admin` */

insert  into `admin`(`username`,`password`) values ('admin','admin');

/*Table structure for table `login` */

DROP TABLE IF EXISTS `login`;

CREATE TABLE `login` (
  `username` varchar(30) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `login` */

insert  into `login`(`username`,`password`) values ('baavi','baavi'),('gowri','gowri'),('raghu','12345'),('likitha','1234567'),('chethana','12345678');

/*Table structure for table `logindetails` */

DROP TABLE IF EXISTS `logindetails`;

CREATE TABLE `logindetails` (
  `username` varchar(30) DEFAULT NULL,
  `logintime` varchar(300) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `logindetails` */

insert  into `logindetails`(`username`,`logintime`) values ('gowri','Thu Nov 22 15:19:59 IST 2018'),('raghu','Thu Nov 22 15:41:34 IST 2018'),('likitha','Thu Nov 22 15:45:31 IST 2018'),('chethana','Thu Nov 22 16:18:23 IST 2018');

/*Table structure for table `regestration` */

DROP TABLE IF EXISTS `regestration`;

CREATE TABLE `regestration` (
  `Accountnum` varchar(30) DEFAULT NULL,
  `Name` varchar(30) DEFAULT NULL,
  `Password` varchar(30) DEFAULT NULL,
  `PhoneNum` varchar(10) DEFAULT NULL,
  `Emailid` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `regestration` */

insert  into `regestration`(`Accountnum`,`Name`,`Password`,`PhoneNum`,`Emailid`) values ('123456','baavi','baavi','8956235689','baavi@gmail.com'),('12343455667','gowri','gowri','8956235689','gowri@gmail.com'),('EPCETISE5-1','raghu','12345','55555555','ragu@gmail.com'),('EPCETISE5-2','likitha','1234567','7899295275','naidulikitha5@gmail.com'),('EPCETISE5-3','chethana','12345678','9611518990','kavyargowda31198gamil.com');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
